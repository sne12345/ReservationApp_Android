package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Frag1 extends Fragment {

    private View view;
    private RelativeLayout relative1;
    private RelativeLayout relative2;
    private ImageView img2;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.frag1, container, false);

        // 클릭 시, SubActivity1로 넘어가기
        RelativeLayout relative1 = (RelativeLayout)view.findViewById(R.id.relative1);
        relative1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getActivity(), SubActivity1.class);
                in.putExtra("some","somedata");
                startActivity(in);
            }
        });

        // 클릭 시, SubActivity2로 넘어가기
        RelativeLayout relative2 = (RelativeLayout)view.findViewById(R.id.relative2);
        relative2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getActivity(), SubActivity2.class);
                in.putExtra("some2","somedata2");
                startActivity(in);
            }
        });

        /*
        // 클릭 시, SubActivity2로 넘어가기
        img2 = (ImageView) view.findViewById(R.id.img2);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "버튼 2을 클릭하였습니다.", Toast.LENGTH_LONG).show();
            }
        });

         */
        return view;
    }


}
